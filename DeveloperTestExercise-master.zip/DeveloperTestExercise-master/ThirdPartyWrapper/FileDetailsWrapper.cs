﻿using FileDetailsInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileDetailsWrapper
{
    /// <summary>
    /// Wrapper class to expose the third party file details
    /// </summary>
    public class FileDetailsWrapper : IFileDetails
    {
        FileDetails fileDetails = new FileDetails();

        /// <summary>
        /// Retrieve the file version number
        /// </summary>
        /// <param name="filePath">string</param>
        /// <returns>version number</returns>
        public string Version(string filePath)
        {
            return fileDetails.Version(filePath);
        }

        /// <summary>
        /// Retrieve the file size 
        /// </summary>
        /// <param name="filePath">string</param>
        /// <returns>size of the file</returns>
        public int Size(string filePath)
        {
            return fileDetails.Size(filePath);
        }
    }
}
