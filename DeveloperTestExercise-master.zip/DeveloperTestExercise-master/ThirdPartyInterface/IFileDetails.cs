﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileDetailsInterface
{
    /// <summary>
    /// Interface to expose the methods required for fileDetails.
    /// </summary>
    public interface IFileDetails
    {
        /// <summary>
        /// Retrieve the file version number
        /// </summary>
        /// <param name="filePath">string</param>
        /// <returns>version number</returns>
        string Version(string filePath);

        /// <summary>
        /// Retrieve the file size 
        /// </summary>
        /// <param name="filePath">string</param>
        /// <returns>size of the file</returns>
        int Size(string filePath);
    }
}
