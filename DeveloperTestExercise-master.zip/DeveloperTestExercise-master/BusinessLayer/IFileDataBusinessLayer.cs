﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    /// <summary>
    /// Business layer Interface, exposes the methods for business validation.
    /// </summary>
    public interface IFileDataBusinessLayer
    {
        /// <summary>
        /// Based on the command this method fetches the version or size details
        /// </summary>
        /// <param name="args"> string array</param>
        /// <returns>The version or the size details based on the command</returns>
        object FetchFileDetails(string[] args);
    }
}
