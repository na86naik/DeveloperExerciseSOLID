﻿using FileDataContainer;
using FileDetailsInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLayer
{
    /// <summary>
    /// Business layer: This layer does the validation and any business related operations
    /// </summary>
    public class FileDataBusinessLayer : IFileDataBusinessLayer
    {
        private IFileDetailsWrapper fileDetails;
        public IFileDetailsWrapper FileDetails
        {
            get;
            set;
        }

        public FileDataBusinessLayer(string key)
        {
            fileDetails = Provider.GetObject(key);
        }

        /// <summary>
        /// Based on the command this method fetches the version or size details
        /// </summary>
        /// <param name="args"> string array</param>
        /// <returns>The version or the size details based on the command</returns>
        public object FetchFileDetails(string[] args)
        {
            // Check the first argument and call the respective method in FileDetails.
            string firstArgument = args[0];
            if (firstArgument.Contains("-") || firstArgument.Contains("--") || firstArgument.Contains("/"))
            {
                firstArgument = Regex.Replace(firstArgument, @"[^0-9a-zA-Z]+", "");

                // call the respective methods to return the desired output.
                switch (firstArgument.ToLower())
                {
                    case "v":
                        return fileDetails.Version(args[1]);
                    case "s":
                        return fileDetails.Size(args[1]);
                    default: 
                        return null;
                }
            }
            return null;
        }        
    }
}
