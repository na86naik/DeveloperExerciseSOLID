﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileDetailsInterface;

namespace FileDetailsController
{
    /// <summary>
    /// Controller class to get the object details for the interface
    /// </summary>
    public class FileDetailsController : IFileDetailsController
    {
        private IFileDetails fieldDetails;

        /// <summary>
        /// Constructor injection
        /// </summary>
        /// <param name="_fieldDetails">IFileDetails</param>
        public FileDetailsController(IFileDetails _fieldDetails)
        {
            this.fieldDetails = _fieldDetails;
        }


        /// <summary>
        /// Controller method to fetch the Version details from the Interface
        /// </summary>
        /// <param name="filePath">string</param>
        /// <returns>version number as a string</returns>
        public string Version(string filePath)
        {
            return fieldDetails.Version(filePath);
        }

        /// <summary>
        /// Controller method to fetch the size details from the Interface
        /// </summary>
        /// <param name="filePath">string</param>
        /// <returns>size as an integer</returns>
        public int Size(string filePath)
        {
            return fieldDetails.Size(filePath);
        }
    }
}
