﻿using FileDetailsInterface;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace FileDataContainer
{
    public class Provider
    {
        /// <summary>
        /// Continer class that provides the required object.
        /// </summary>
        /// <param name="key">string</param>
        /// <returns>FileDetailsController.FileDetailsController</returns>
        public static FileDetailsController.FileDetailsController GetObject()
        {
            IUnityContainer unitycontainer = new UnityContainer();
            unitycontainer.RegisterType<IFileDetails, FileDetailsWrapper.FileDetailsWrapper>();
            return unitycontainer.Resolve<FileDetailsController.FileDetailsController>();
        }
    }
}
