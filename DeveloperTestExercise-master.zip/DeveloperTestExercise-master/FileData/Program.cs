﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using FileDetailsController;
using System.Configuration;

namespace FileData
{
    public static class Program
    {
        public static object output = null;
        
        public static void Main(string[] args)
        {
            if (args.Length > 0)
            {                          

                // Fetch the object details from the container.
                FileDetailsController.FileDetailsController fileDetails = FileDataContainer.Provider.GetObject();
                
                // Check the first argument and call the respective method in FileDetails.
                string firstArgument = args[0];
                if (firstArgument.Contains("-") || firstArgument.Contains("--") || firstArgument.Contains("/"))
                {
                    firstArgument = Regex.Replace(firstArgument, @"[^0-9a-zA-Z]+", "");

                    // call the respective methods to return the desired output.
                    switch (firstArgument.ToLower())
                    {
                        case "v":
                            output = fileDetails.Version(args[1]);
                            break;
                        case "s":
                            output = fileDetails.Size(args[1]);
                            break;
                    }                   
                }

                // Display the output result
                Console.WriteLine("{0}", output);
            }
        }
    }
}
